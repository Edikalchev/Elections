
-- --------------------------------------------------------

--
-- Table structure for table `party`
--

DROP TABLE IF EXISTS `party`;
CREATE TABLE IF NOT EXISTS `party` (
  `parID` int(11) NOT NULL AUTO_INCREMENT,
  `Pname` varchar(45) NOT NULL,
  `voteNum` int(11) NOT NULL,
  `canID` int(11) NOT NULL,
  PRIMARY KEY (`parID`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COMMENT='Parties for elections	';

--
-- Dumping data for table `party`
--

INSERT INTO `party` (`parID`, `Pname`, `voteNum`, `canID`) VALUES
(1, 'Liberal Party', 1, 4),
(2, 'Conservatives', 2, 3),
(3, 'Green Party', 3, 2),
(4, 'Bloc Quebecois', 4, 6),
(5, 'Canadian Acrion Party', 5, 9),
(6, 'Christian Heritage Party', 6, 8),
(7, 'Communist Party', 7, 1),
(8, 'Libertarian Party', 8, 7),
(9, 'Marijuana Party', 9, 5),
(10, 'Marxist-Leninist Party', 10, 10),
(11, 'New Democratic Party', 11, 11),
(12, 'Progressive Canadian Party', 12, 12),
(13, 'Western Canada Concept Party', 13, 13);
