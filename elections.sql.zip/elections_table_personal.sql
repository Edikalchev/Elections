
-- --------------------------------------------------------

--
-- Table structure for table `personal`
--

DROP TABLE IF EXISTS `personal`;
CREATE TABLE IF NOT EXISTS `personal` (
  `PID` int(11) NOT NULL AUTO_INCREMENT,
  `SIN` varchar(50) NOT NULL,
  `Region` int(11) NOT NULL,
  `fName` varchar(45) NOT NULL,
  `lName` varchar(45) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` int(11) NOT NULL,
  PRIMARY KEY (`PID`),
  UNIQUE KEY `SIN_UNIQUE` (`SIN`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1 COMMENT='information of voters';

--
-- Dumping data for table `personal`
--

INSERT INTO `personal` (`PID`, `SIN`, `Region`, `fName`, `lName`, `Age`, `Gender`) VALUES
(1, '100000000', 1, 'Jane', 'Doe', 30, 0),
(2, '100000001', 1, 'Mark', 'Smith', 20, 1),
(3, '100000002', 3, 'Kirk', 'Smith', 55, 1),
(4, '100000003', 9, 'First', 'Last', 34, 1),
(5, '100000004', 3, 'First', 'Last', 22, 0),
(6, '100000005', 8, 'Jon', 'Doe', 18, 1),
(7, '100000006', 2, 'Tom', 'Dover', 60, 1),
(8, '100000007', 3, 'Lara', 'Lauren', 45, 0),
(9, '100000008', 7, 'Jack', 'Jackson', 38, 1),
(10, '100000009', 5, 'A', 'B', 20, 1),
(11, '100000010', 6, 'C', 'D', 46, 0),
(12, '100000011', 13, 'Person', 'A', 38, 0),
(13, '100000012', 12, 'Person', 'B', 55, 1),
(14, '100000013', 1, 'Person', 'C', 42, 0),
(15, '100000014', 4, 'Person', 'D', 80, 1),
(16, '100000015', 10, 'Person', 'E', 28, 1),
(17, '100000016', 11, 'Person', 'F', 39, 0),
(18, '100000017', 4, 'Person', 'G', 40, 0),
(19, '100000018', 2, 'Person', 'H', 99, 1),
(20, '100000019', 1, 'Person', 'I', 28, 0),
(21, '100000020', 3, 'Lasr', 'Person', 19, 1);
