
-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

DROP TABLE IF EXISTS `candidates`;
CREATE TABLE IF NOT EXISTS `candidates` (
  `CID` int(11) NOT NULL,
  `CfName` varchar(45) NOT NULL,
  `ClName` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Candidates for Election';

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`CID`, `CfName`, `ClName`) VALUES
(1, 'Murray', 'Ferdinand'),
(2, 'Dennis', 'Geoffrey'),
(3, 'Blake', 'Bennett'),
(4, 'Rachel', 'Isabel'),
(5, 'Reagan', 'Clare'),
(6, 'Sidney', 'Aletha'),
(7, 'Silvester', 'Fenton'),
(8, 'Edison', 'Elvis'),
(9, 'Deanne', 'Dawn'),
(10, 'Byron', 'Lachlan'),
(11, 'Shelton', 'Breanna'),
(12, 'Duke', 'Marshal'),
(13, 'Raymond', 'Danica');
