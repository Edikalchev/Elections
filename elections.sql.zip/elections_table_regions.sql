
-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

DROP TABLE IF EXISTS `regions`;
CREATE TABLE IF NOT EXISTS `regions` (
  `RID` int(11) NOT NULL,
  `City` varchar(45) NOT NULL,
  `Province` varchar(45) NOT NULL,
  PRIMARY KEY (`RID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Regions of Canada';

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`RID`, `City`, `Province`) VALUES
(1, 'Toronto', 'ON'),
(2, 'Quebec City', 'QC'),
(3, 'Regina', 'SK'),
(4, 'Fredericton', 'NB'),
(5, 'Ottawa', 'ON'),
(6, 'Montreal', 'QC'),
(7, 'Victoria', 'BC'),
(8, 'Vancouver', 'BC'),
(9, 'Edmonton', 'AB'),
(10, 'Calgary', 'AB'),
(11, 'Winnipeg', 'MT'),
(12, 'Halifax', 'NS'),
(13, 'Charlottetown', 'PEI'),
(14, 'St. Johns', 'NF'),
(15, 'Yellowknife', 'NWT'),
(16, 'Iqaluit', 'NU'),
(17, 'Whitehorse', 'YK');
